//Before Run this program first check the url, Username, Password in "hibernate.cfg.xml" file.

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.hibernate.ObjectNotFoundException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class Main {
	static Scanner input = new Scanner(System.in);

	public static void main(String[] args){
		
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		cfg.addAnnotatedClass(Course.class);
		cfg.addAnnotatedClass(Student.class);
		
		SessionFactory sf=cfg.buildSessionFactory();
		
		
		Student student=new Student();
		
		
		Session session=sf.openSession();
		Transaction transaction=session.beginTransaction();
		
		session.saveOrUpdate(CourseList.course1());
		session.saveOrUpdate(CourseList.course2());
		session.saveOrUpdate(CourseList.course3());
		session.saveOrUpdate(CourseList.course4());
		session.saveOrUpdate(CourseList.course5());

		
		System.out.println("\n\t\tStudent Course Registration System");
		System.out.println("\t\t---------------------------------------\n\n");
		
		Query<Course>query1=session.createQuery("from Course");
		List<Course>list1=query1.list();
		for(Course course:list1) {
			System.out.println(course);
			System.out.println();
		}
		
		
		System.out.println("\n\nchoose one option\n\n1. Start regisration\n2. Drop courses\n3. Exit");
		boolean a= true;		
		while(a) {
			System.out.print("\nSelect an option : ");
			int option1=input.nextInt();
			
			if(option1==1) {
				System.out.print("Enter Student Id :  ");
				int id=input.nextInt();
				student.setSId(id);
				
				System.out.print("\nEnter Student Name : ");
				String name=input.next();
				student.setSName(name);
				
				System.out.println("\nRegister for courses");
				System.out.println("1. Java\n2. Python\n3. AWS\n4. Devops\n5. FrontEnd");
				Set<Integer>selectedOptions=new HashSet<>();
				List<Course>selectedCourses=new ArrayList<>();
				Course selectCourse=null;
				
				boolean b=true;
				while(b) {
					System.out.print("\nSelect an option : ");
					int option2=input.nextInt();
					
					if(selectedOptions.contains(option2)) {
						System.out.println("You already Registered this Course!!!!, please select another Course or Exit");
						continue;
					}
					
					boolean isvalid=false;
					while(!isvalid) {
						if(option2==1) {
							selectCourse= session.get(Course.class,101);
							selectedCourses.add(selectCourse);
							
							System.out.println("Press 0 to exit or choose another course");
							isvalid=true;
						}
						else if(option2==2) {
							selectCourse=session.get(Course.class,201);
							selectedCourses.add(selectCourse);
							
							System.out.println("Press 0 to exit or choose another course");
							isvalid=true;;
						}
						else if(option2==3) {
							selectCourse=session.get(Course.class,301);
							selectedCourses.add(selectCourse);
							
							System.out.println("Press 0 to exit or choose another course");
							isvalid=true;
						}
						else if(option2==4) {
							selectCourse=session.get(Course.class,401);
							selectedCourses.add(selectCourse);
							
							System.out.println("Press 0 to exit or choose another course");
							isvalid=true;
						}
						else if(option2==5) {
							selectCourse=session.get(Course.class,501);
							selectedCourses.add(selectCourse);
							
							System.out.println("Press 0 to exit or choose another course");
							isvalid=true;;
						}
						else if(option2==0){
							System.out.println("\nExit");
							isvalid=true;
							b=false;
						}
						else {
							System.out.println("\nInvalid opion!, please select an Options from the above");
							break;
						}
						if(isvalid) {
							selectedOptions.add(option2);
							
						}
					}
				}
				student.setCourses(selectedCourses);
				session.save(student);
				
				Query<Student>query2=session.createQuery("from Student");
				List<Student>list2=query2.list();
				for(Student s:list2) {
					System.out.println(s);
					System.out.println();
				}
				a=false;
				
			}
			else if(option1==2) {
				System.out.print("\nEnter Student Id : ");
				int id=input.nextInt();
				System.out.println();
				try {
					
					Student stData=session.get(Student.class,id);
					System.out.println(stData);
					System.out.println("\nRegistered Courses\n");
					
					List<Course> cData=stData.getCourses();
					for(Course co:cData) {
						System.out.println(co);
					}
					
					boolean c=true;
					while(c) {
						System.out.print("\nEnter 1 to drop Courses or 0 to Exit : ");
						int option3=input.nextInt();
						if(option3==0) {
							System.out.println("Exit");
							c=false;
							a=false;
						}
						else if(option3==1) {
					
							System.out.print("Enter the Course name you want to Delete : ");
							String name=input.next();
							
							Course dropCourse=null;
							for(Course cou:cData) {
								if(cou.getCName().equalsIgnoreCase(name)) {
									dropCourse=cou;
									break;
								}
							}
								
								if(dropCourse!=null) {
									cData.remove(dropCourse);
									stData.setCourses(cData);
								
									session.saveOrUpdate(stData);
									System.out.println("\nCourse Dropped Successfully");
									System.out.println();
									for(Course course:cData) {
										System.out.println(course);
									}
								}
								else {
									System.out.println("\nCourse Not Found");
								}
							}
						
						else {
							System.out.println("Wrong Input");
						}
					}
					
				}
				catch(ObjectNotFoundException e) {
					System.out.println("The Id is not Registered, go to Registration form to register");
					System.out.println("Exit");
				}
				a=false;
				
			}
			
			else if(option1==3) {
				System.out.println("\nExit");
				a=false;
			}
			else {
				System.out.println("Select an Option from the above");
				
			}
		}
		
		
		transaction.commit();
		session.close();
	}
}
