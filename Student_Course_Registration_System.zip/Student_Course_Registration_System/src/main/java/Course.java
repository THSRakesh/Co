import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Column;

import jakarta.persistence.ManyToMany;
import java.util.List;



@Entity
public class Course {
	@Id
	@Column(name="code")
	int cId;
	
	@Column(name="Title")
	String cName;
	
	@Column(name="Description")
	String cDescription;
	
	@Column(name="Capacity")
	int capacity;
	
	@Column(name="Schedule")
	String cTimings;
	
	@ManyToMany(mappedBy ="courses")
	private List<Student>students;
	
	//Setters
	public void setCId(int cId) {
		this.cId=cId;
	}
	
	public void setCName(String cName) {
		this.cName=cName;
	}
	
	public void setCDescription(String cDescription) {
		this.cDescription=cDescription;
	}
	
	public void setCapacity(int capacity) {
		this.capacity=capacity;
	}
	
	public void setCTimings(String cTimings) {
		this.cTimings=cTimings;
	}
	
	public void setStudents(List<Student> students) {
		this.students=students;
	}
	
	//Getters
	
	public int getCId() {
		return cId;
	}
	
	public String getCName() {
		return cName;
	}
	
	public String getCDescription() {
		return cDescription;
	}
	
	public int getCapacity() {
		return capacity;
	}
	
	public String getCTimings() {
		return cTimings;
	}
	
	public List<Student> getStudents(){
		return students;
	}
	
	
	@Override
	public String toString() {
		return "Course [cId=" + cId + ", cName=" + cName + ", cDescription=" + cDescription + ", capacity=" + capacity
				+ ", cTimings=" + cTimings + "]";
	}
	
}
