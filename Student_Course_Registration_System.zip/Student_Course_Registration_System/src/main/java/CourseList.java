public class CourseList {
	
	public static Course course1() {
		Course course1=new Course();
		course1.setCId(101);
		course1.setCName("Java");
		course1.setCDescription("Prof. 111XYZ");
		course1.setCapacity(40);
		course1.setCTimings("10:00 AM");
		
		return course1;
	}
	
	public static Course course2() {
		Course course2=new Course();
		course2.setCId(201);
		course2.setCName("Python");
		course2.setCDescription("Prof. 222XYZ");
		course2.setCapacity(35);
		course2.setCTimings("12:00 PM");
		
		return course2;
	}
	
	public static Course course3() {
		Course course3=new Course();
		course3.setCId(301);
		course3.setCName("AWS");
		course3.setCDescription("Prof. 333XYZ");
		course3.setCapacity(25);
		course3.setCTimings("2:00 PM");
		
		return course3;
	}
	
	public static Course course4() {
		Course course4=new Course();
		course4.setCId(401);
		course4.setCName("Devops");
		course4.setCDescription("Prof. 444XYZ");
		course4.setCapacity(30);
		course4.setCTimings("4:00 PM");
		
		return course4;
	}
	
	public static Course course5() {
		Course course5=new Course();
		course5.setCId(501);
		course5.setCName("FrontEnd");
		course5.setCDescription("Prof. 555XYZ");
		course5.setCapacity(30);
		course5.setCTimings("4:00 PM");
		
		return course5;
	}
}