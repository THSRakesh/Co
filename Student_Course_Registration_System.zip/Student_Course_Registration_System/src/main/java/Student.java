import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;

import java.util.List;


@Entity
public class Student {
	
	@Id
	@Column(name="Id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int sId;
	
	@Column(name="Name")
	String sName;
	
	@ManyToMany
	@JoinTable(name="Student_Course",
			joinColumns =  @JoinColumn(name="Student_id"),
			inverseJoinColumns = @JoinColumn(name="Couse_id"))
	List<Course> courses;
	
	//Setters
	public void setSId(int sId) {
		this.sId=sId;
	}
	
	public void setSName(String sName) {
		this.sName=sName;
	}
	
	public void setCourses(List<Course> courses) {
		this.courses=courses;
	}
	
	
	//Getters
	public int getSId() {
		return sId;
	}
	
	public String getSName() {
		return sName;
	}
	
	public List<Course> getCourses() {
		return courses;
	}

	@Override
	public String toString() {
		return "Student [sId=" + sId + ", sName=" + sName + ", Courses= "+courses +"]";
	}
	
}
