import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.query.Query;

public class Registration {
	public static void studentRegistration(Session session) {

		System.out.println("\n\nchoose one option\n\n1. Start regisration\n2. Drop courses\n43. Exit");
				
		while(true) {
			System.out.print("\nSelect an option : ");
			int option1=input.nextInt();
			
			if(option1==1) {
				System.out.print("Enter Student Id :  ");
				int id=input.nextInt();
				student.setSId(id);
				
				System.out.print("\nEnter Student Name : ");
				String name=input.nextLine();
				student.setSName(name);
				
				System.out.println("\nRegister for courses");
				System.out.println("1. Java\n2. Python\n3. AWS\n4. Devops\n5. FrontEnd");
				Set<Integer>selectedOptions=new HashSet<>();
				
				while(true) {
					System.out.print("\nSelect an option : ");
					int option2=input.nextInt();
					
					if(selectedOptions.contains(option2)) {
						System.out.println("You already Registered this Course!!!!, please select another Course or Exit");
						continue;
					}
					
					boolean isvalid=false;
					while(!isvalid) {
						if(option2==1) {
							student.setCId(CourseList.course1());
							isvalid=true;
						}
						else if(option2==2) {
							student.setCId(CourseList.course2());
							isvalid=true;;
						}
						else if(option2==3) {
							student.setCId(CourseList.course3());
						isvalid=true;
						}
						else if(option2==4) {
							student.setCId(CourseList.course4());
							isvalid=true;
						}
						else if(option2==5) {
							student.setCId(CourseList.course5());
							isvalid=true;;
						}
						else if(option2==0){
							System.out.println("\nExit");
							return;
						}
						else {
							System.out.println("\nInvalid opion!, please select an Options from the above");
							break;
						}
						if(isvalid) {
							selectedOptions.add(option2);
						}
					}
					
					Query<Student>query2=session.createQuery("from Student");
					List<Student>list2=query2.list();
					for(Student s:list2) {
						System.out.println(s);
					}
				}
				
			}
			else if(option1==2) {
				
			}
		}

	}
}
